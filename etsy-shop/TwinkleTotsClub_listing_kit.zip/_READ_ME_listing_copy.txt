# TwinkleTotsClub — Etsy Listing Kit

Everything here is ready to upload to your Etsy listing for **Fun Kids Learning Printables**.

---

## 📁 What's in this folder

| Folder | What it is | Use it for |
|---|---|---|
| `listings/` | 6 finished 2000×2000 JPG listing images | Upload as your **Photos** (in order) |
| `videos/` | 2 MP4 videos (12s each) | Upload as your **Videos** (Etsy allows 2) |
| `assets/` | The raw worksheet art + photos used as bases | Source files if you want to re-edit |
| `designs/` | 6 bonus "Celestial Botanical" art prints | A **second** listing (see below) |
| `fonts/` | Fonts used (Fredoka, Nunito, Baloo 2, Quicksand, Andika) | Re-editing; all SIL Open Font License |
| `build_listings.py` / `build_video.py` | The scripts that generated everything | Re-run to rebuild after edits |

---

## 🖼️ Photos — upload in this order

1. **`01_hero.jpg`** — main image: title + fanned worksheets + feature pills
2. **`02_whats_inside.jpg`** — flatlay showing the real tracing worksheet
3. **`03_benefits.jpg`** — "Learning that feels like play" — 4 benefit cards
4. **`04_who_for.jpg`** — "Big smiles, busy hands" — ages 2-4, 3-5, 5-6
5. **`05_how_it_works.jpg`** — buy → download → print (kills support questions)
6. **`06_video_cover.jpg`** — cover frame for the video

## 🎬 Videos

| File | Ratio | Use |
|---|---|---|
| `videos/listing_video_square.mp4` | 1080×1080 | **Etsy listing video** (upload this one) |
| `videos/listing_video_vertical.mp4` | 1080×1920 | Pinterest / Instagram Reels / TikTok |

Both are 12 seconds, silent, no music (Etsy auto-mutes videos anyway). Ken Burns pan + crossfade through all six images.

---

## ✍️ Copy-paste listing details

### Title (140 char max)
```
Fun Kids Learning Printables | Preschool Worksheets Bundle | Alphabet Tracing Numbers Coloring | Toddler Busy Book | Instant Download
```

### Tags (max 13 tags, 20 chars each)
```
preschool worksheet
kids learning print
alphabet tracing
toddler busy book
homeschool printable
number tracing
coloring pages kids
kindergarten prep
instant download
learning bundle
montessori kids
quiet time activity
fine motor skills
```

### Description
```
FUN KIDS LEARNING PRINTABLES — 40+ Preschool Worksheets

Instant download. Print at home. No waiting, no shipping.

Turn "I'm bored" into "Can I do another one?"

This bundle is packed with the preschool basics — the letters, numbers and
colouring pages little ones actually ask for. Made for busy hands and short
attention spans: big friendly letters, thick tracing lines, and pictures to
colour when sitting still gets hard.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT YOU GET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✔ A–Z letter tracing pages (uppercase & lowercase)
✔ Numbers 1–20 with counting pictures
✔ Colouring pages — animals, rainbows, shapes
✔ Shapes, patterns & feelings worksheets
✔ 40+ pages in total, print as many times as you like

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PERFECT FOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Toddlers & preschoolers (ages 2–6)
• Parents needing a screen-free 20 minutes
• Grandparents — brilliant for the kitchen table
• Preschool, daycare, homeschool & travel

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW IT WORKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Buy — checkout takes a minute
2. Download — files are ready instantly in your Etsy downloads
3. Print — at home or at a print shop, as many copies as you want

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT'S INCLUDED IN THE DOWNLOAD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Print-ready PDF, A4 and US Letter sizes
• High-resolution JPG versions of every page
• A simple printing guide

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PLEASE NOTE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• This is a DIGITAL DOWNLOAD — no physical item is shipped
• Colours may vary slightly between screens and printers
• For personal use and single-classroom use. Please don't resell
  or redistribute the files themselves.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW THIS WAS MADE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Created with the use of AI tools for the artwork and page design,
then assembled, laid out, edited and print-tested by me. Worksheet
content, layout, wording and design direction are my own original work.

Because I enjoyed making it, more bundles are on the way —
click the ♥ to follow the shop so you don't miss them.

Thanks for supporting a small shop!
```

---

## ⚙️ Etsy listing settings (important)

| Field | Set it to |
|---|---|
| **Type** | Digital (listing type dropdown) |
| **Category** | Paper & Party Supplies → Paper → Stationery → Educational Printables |
| **Who made it** | *I did* (Etsy calls AI-assisted work "Designed by a seller") |
| **When made** | *Made to order* |
| **What is it** | *A finished product* |
| **Files** | Upload PDF + JPGs. **Etsy allows max 5 files, 20MB each** — so zip the bundle and split if you're over. |
| **Price suggestion** | $4.99–$7.99 for a 40+ page bundle |

### ⚠️ Etsy's two rules you must not skip
1. **Disclose AI in the listing description.** Not in tags, not in the photo — in the *description*. The paragraph under "HOW THIS WAS MADE" above does this. Don't remove it.
2. **Never sell the prompts themselves.** AI prompt bundles are banned on Etsy. Selling AI-made artwork with disclosure is fine.

---

## 🎨 Bonus: the second listing (`designs/`)

Six ready art prints in a "Celestial Botanical" set — same palette (ivory, sage, terracotta, clay), so they sell as a matching gallery wall. These could be listed as a separate printable wall-art listing, or as a free-with-purchase bonus to boost reviews on this listing.

---

## 🔧 Re-editing

```bash
cd etsy-shop
python3 build_listings.py     # rebuild all 6 listing images from assets/
python3 build_video.py        # rebuild both videos
```

To change wording, edit the text inside the `build_*()` functions. Everything is drawn with big shapes and outlines so it stays sharp at any size.
